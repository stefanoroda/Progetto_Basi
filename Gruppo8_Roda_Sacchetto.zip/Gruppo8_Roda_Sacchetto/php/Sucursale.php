<?php 

    //IMPORTA LA CONNESSIONE DEL DATABASE

    //CONTROLLO CHE I VALORI INIVIATI NON SIANO NULLI
    //if $var != NULL CONTROLLO CHE LA VARIABILE NON SIA NULLA
    $COD_SUC   = $_POST['COD_SUC'];
    $DIPARTIMENTO = $_POST['DIPARTIMENTO'];
    $VIA = $_POST['VIA'];
    $NUMERO = $_POST['NUMERO'];
    $CAP = $_POST['CAP'];
    $CITTA = $_POST['CITTA'];



    //INTERROGAZIONI (QUERY)


?>

<html>

    <head>
    
        <title>Pagina Sucursale</title>
        <!-- INSERIMENTO DELLO STILE GRAFICO -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">

    <head>

    <body>
        <!-- STAMPA INSERIMENTO -->

    </body>
</html>