USE BIBLIOTECA;
INSERT INTO UTENTE (MATRICOLA, NUMERO_TEL, CAP, NUMERO, VIA, CITTA, COGNOME, NOME)
VALUES
  (1, '1234567890', '12345', '1', 'Via Roma', 'Roma', 'Rossi', 'Mario'),
  (2, '9876543210', '54321', '10', 'Via Verdi', 'Milano', 'Bianchi', 'Laura'),
  (3, '5555555555', '67890', '5', 'Via San Martino', 'Napoli', 'Verdi', 'Luigi'),
  (4, '1111111111', '45678', '15', 'Via Monti', 'Torino', 'Ferrari', 'Giovanni'),
  (5, '2222222222', '98765', '3', 'Via dei Fiori', 'Firenze', 'Russo', 'Giulia'),
  (6, '3333333333', '54321', '8', 'Via Mazzini', 'Bologna', 'Esposito', 'Antonio'),
  (7, '4444444444', '23456', '7', 'Via Garibaldi', 'Genova', 'Romano', 'Francesca'),
  (8, '5555555555', '34567', '12', 'Via degli Ulivi', 'Palermo', 'Galli', 'Sara'),
  (9, '6666666666', '87654', '4', 'Via Carducci', 'Verona', 'Conti', 'Marco'),
  (10, '7777777777', '12345', '2', 'Via Veneto', 'Venezia', 'Leone', 'Martina'),
  (11, '8888888888', '67890', '9', 'Via Dante', 'Padova', 'Marini', 'Simone'),
  (12, '9999999999', '34567', '6', 'Via dei Pini', 'Cagliari', 'Cattaneo', 'Alessia'),
  (13, '0000000000', '45678', '18', 'Via dei Gelsomini', 'Cosenza', 'Rizzo', 'Lorenzo'),
  (14, '1212121212', '23456', '14', 'Via dei Tigli', 'Perugia', 'Ferri', 'Valentina'),
  (15, '2323232323', '98765', '11', 'Via Leopardi', 'Rimini', 'Martini', 'Elisa'),
  (16, '3434343434', '87654', '6', 'Via dei Cipressi', 'Pisa', 'Rossini', 'Roberto'),
  (17, '4545454545', '12345', '3', 'Via dei Girasoli', 'Bari', 'De Luca', 'Chiara');